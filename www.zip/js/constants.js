angular.module('citizen-engagement')
  .constant('apiUrl', 'https://comem-citizen-engagement-2017f.herokuapp.com/api')
  .constant('mapboxSecret', 'undefined')
  .constant('qimgUrl', 'https://comem-qimg.herokuapp.com/api')
  .constant('qimgSecret', '2708ikdCZ0h5ss/6si5P1urmxLLA7ekKq3lE8JpdJjSE2PEVBvvUmbzaOR17Y/fvCT47vNPDZiJ99TVhBGKY2BUJQyGYSlwyBIP8T2njnsnnSqkRIhXlcZZXhrF3OTmKC+v7kJ7ffWRJNgm+lowaA/F+CIvVUFShFbewckBR+Yw=')
;