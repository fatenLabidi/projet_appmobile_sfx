angular.module('citizen-engagement')
  .constant('apiUrl', '/api-proxy')
  .constant('mapboxSecret', 'undefined')
;